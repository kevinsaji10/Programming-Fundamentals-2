/*
 *
 * Name:
 */

public class InvalidInfoException {
   
}