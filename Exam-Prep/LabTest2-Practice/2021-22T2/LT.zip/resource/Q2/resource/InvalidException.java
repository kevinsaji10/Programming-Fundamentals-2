/*
 *
 * Name:
 */

public class InvalidException extends RuntimeException{
    
}
