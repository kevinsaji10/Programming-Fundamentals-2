package school.app.exception;
/*
 *
 * Name:
 */

public class InvalidException extends RuntimeException{
    
}
