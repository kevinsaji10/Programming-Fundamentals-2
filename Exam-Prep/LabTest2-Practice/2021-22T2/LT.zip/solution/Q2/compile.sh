javac -d out -cp external/apache/*:src:given src/school/app/Application.java
