java -cp out:external/apache/*:given school.app.Application
