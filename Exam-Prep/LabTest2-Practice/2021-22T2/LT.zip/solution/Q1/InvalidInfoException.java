public class InvalidInfoException extends Exception{
    public InvalidInfoException(String message){
        super(message);
    }
    
}