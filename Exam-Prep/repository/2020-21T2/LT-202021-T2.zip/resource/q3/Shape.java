public class Shape {

    public Shape(){

    }

    public String toString() {
        return "(" + this.getClass().getName() + ")";
    }
}
