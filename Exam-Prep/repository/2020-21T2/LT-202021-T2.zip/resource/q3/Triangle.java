public class Triangle extends Shape {
    
}