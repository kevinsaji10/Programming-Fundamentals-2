
public class InvalidTestException {
    
}
