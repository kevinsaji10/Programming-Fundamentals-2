

public class Snack extends Product {

    public Snack(String name, int price) {
        super(name, price);
    }
}
