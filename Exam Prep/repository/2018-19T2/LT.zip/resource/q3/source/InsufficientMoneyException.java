

public class InsufficientMoneyException extends Exception {
}
