

public class Secretary {

}
